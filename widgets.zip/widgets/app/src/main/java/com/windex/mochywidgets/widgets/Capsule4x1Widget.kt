package com.windex.mochywidgets.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.windex.mochywidgets.R
import com.windex.mochywidgets.core.MediaBridgeService
import com.windex.mochywidgets.core.NowPlayingState
import com.windex.mochywidgets.core.WidgetRegistry

class Capsule4x1Widget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        MediaBridgeService.instance?.pushStateToWidgets()
            ?: updateAllInstances(context, WidgetRegistry.currentState)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action.startsWith("com.windex.mochywidgets.ACTION_")) {
            MediaBridgeService.instance?.handleCommand(action)
        }
    }

    companion object {
        private fun buildPendingIntent(context: Context, action: String, reqCode: Int): PendingIntent {
            val intent = Intent(context, Capsule4x1Widget::class.java).apply {
                this.action = action
            }
            return PendingIntent.getBroadcast(
                context,
                reqCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        fun updateAllInstances(context: Context, state: NowPlayingState) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, Capsule4x1Widget::class.java))
            if (ids.isEmpty()) return

            val views = RemoteViews(context.packageName, R.layout.widget_capsule_4x1)

            val fullTitle = if (state.artist.isNotBlank()) {
                "${state.title} • ${state.artist}"
            } else {
                state.title
            }
            views.setTextViewText(R.id.txt_track_title, fullTitle)

            if (state.albumArt != null) {
                views.setImageViewBitmap(R.id.img_album_art, state.albumArt)
            } else {
                views.setImageViewResource(R.id.img_album_art, R.drawable.bg_album_circle)
            }

            views.setImageViewResource(
                R.id.btn_play_pause,
                if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play
            )
            views.setImageViewResource(
                R.id.btn_like,
                if (state.isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
            )
            views.setImageViewResource(
                R.id.btn_shuffle,
                if (state.isShuffle) R.drawable.ic_shuffle_active else R.drawable.ic_shuffle
            )

            views.setOnClickPendingIntent(
                R.id.btn_like,
                buildPendingIntent(context, MediaBridgeService.ACTION_LIKE, 1)
            )
            views.setOnClickPendingIntent(
                R.id.btn_prev,
                buildPendingIntent(context, MediaBridgeService.ACTION_PREV, 2)
            )
            views.setOnClickPendingIntent(
                R.id.btn_play_pause,
                buildPendingIntent(context, MediaBridgeService.ACTION_PLAY_PAUSE, 3)
            )
            views.setOnClickPendingIntent(
                R.id.btn_next,
                buildPendingIntent(context, MediaBridgeService.ACTION_NEXT, 4)
            )
            views.setOnClickPendingIntent(
                R.id.btn_shuffle,
                buildPendingIntent(context, MediaBridgeService.ACTION_SHUFFLE, 5)
            )
            views.setOnClickPendingIntent(
                R.id.img_album_art,
                buildPendingIntent(context, MediaBridgeService.ACTION_OPEN_PLAYER, 6)
            )
            views.setOnClickPendingIntent(
                R.id.txt_track_title,
                buildPendingIntent(context, MediaBridgeService.ACTION_OPEN_PLAYER, 7)
            )

            for (id in ids) {
                manager.updateAppWidget(id, views)
            }
        }
    }
}
