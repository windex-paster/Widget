package com.windex.mochywidgets.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.Rating
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.view.KeyEvent

class MediaBridgeService : NotificationListenerService() {

    private var sessionManager: MediaSessionManager? = null
    private var activeController: MediaController? = null
    private val likedTrackIds = mutableSetOf<String>()
    private var localShuffleState = false

    private val sessionsChangedListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            bindBestController(controllers)
        }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            pushStateToWidgets()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            pushStateToWidgets()
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        initMediaSessionTracking()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        initMediaSessionTracking()
    }

    override fun onDestroy() {
        activeController?.unregisterCallback(controllerCallback)
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsChangedListener)
        } catch (_: Exception) {}
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun initMediaSessionTracking() {
        try {
            val mgr = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            sessionManager = mgr
            val comp = ComponentName(this, MediaBridgeService::class.java)
            mgr.addOnActiveSessionsChangedListener(sessionsChangedListener, comp)
            bindBestController(mgr.getActiveSessions(comp))
        } catch (_: SecurityException) {
            // Пользователь ещё не выдал доступ к уведомлениям
        }
    }

    private fun bindBestController(controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) {
            activeController?.unregisterCallback(controllerCallback)
            activeController = null
            WidgetRegistry.updateAllWidgets(this, NowPlayingState())
            return
        }

        // Приоритет отдаём плееру Mochy, иначе берём активный играющий плеер
        val mochyController = controllers.firstOrNull {
            it.packageName.contains("mochy", ignoreCase = true)
        }
        val playingController = controllers.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        }
        val chosen = mochyController ?: playingController ?: controllers.first()

        if (activeController?.sessionToken != chosen.sessionToken) {
            activeController?.unregisterCallback(controllerCallback)
            activeController = chosen
            chosen.registerCallback(controllerCallback)
        }
        pushStateToWidgets()
    }

    fun pushStateToWidgets() {
        val controller = activeController
        if (controller == null) {
            WidgetRegistry.updateAllWidgets(this, NowPlayingState())
            return
        }

        val meta = controller.metadata
        val pb = controller.playbackState

        val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?.takeIf { it.isNotBlank() } ?: "Mochy"
        val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?.takeIf { it.isNotBlank() } ?: ""

        val rawBitmap = meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val circleBitmap = BitmapUtils.cropCircle(rawBitmap)

        val isPlaying = pb?.state == PlaybackState.STATE_PLAYING ||
            pb?.state == PlaybackState.STATE_BUFFERING

        val trackKey = "$artist|$title"
        val userRating = meta?.getRating(MediaMetadata.METADATA_KEY_USER_RATING)
        val isLiked = (userRating != null && userRating.hasHeart()) || likedTrackIds.contains(trackKey)

        val state = NowPlayingState(
            title = title,
            artist = artist,
            isPlaying = isPlaying,
            isLiked = isLiked,
            isShuffle = localShuffleState,
            albumArt = circleBitmap,
            packageName = controller.packageName
        )
        WidgetRegistry.updateAllWidgets(this, state)
    }

    fun handleCommand(action: String) {
        if (activeController == null) {
            initMediaSessionTracking()
        }
        val controller = activeController ?: return
        val controls = controller.transportControls

        when (action) {
            ACTION_PLAY_PAUSE -> {
                val pb = controller.playbackState?.state
                if (pb == PlaybackState.STATE_PLAYING) {
                    controls.pause()
                } else {
                    controls.play()
                }
            }
            ACTION_PREV -> controls.skipToPrevious()
            ACTION_NEXT -> controls.skipToNext()
            ACTION_LIKE -> {
                val meta = controller.metadata
                val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
                val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
                val key = "$artist|$title"
                val nowLiked = if (likedTrackIds.contains(key)) {
                    likedTrackIds.remove(key)
                    false
                } else {
                    likedTrackIds.add(key)
                    true
                }
                try {
                    controls.setRating(Rating.newHeartRating(nowLiked))
                } catch (_: Exception) {}
                pushStateToWidgets()
            }
            ACTION_SHUFFLE -> {
                localShuffleState = !localShuffleState
                try {
                    // Отправляем стандартную команду медиа-кнопки или обновляем индикатор
                    controller.dispatchMediaButtonEvent(
                        KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK)
                    )
                } catch (_: Exception) {}
                pushStateToWidgets()
            }
            ACTION_OPEN_PLAYER -> {
                try {
                    val sessionIntent = controller.sessionActivity
                    if (sessionIntent != null) {
                        sessionIntent.send()
                        return
                    }
                } catch (_: Exception) {}
                val launch = packageManager.getLaunchIntentForPackage(controller.packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                }
            }
        }
    }

    companion object {
        const val ACTION_PLAY_PAUSE = "com.windex.mochywidgets.ACTION_PLAY_PAUSE"
        const val ACTION_PREV = "com.windex.mochywidgets.ACTION_PREV"
        const val ACTION_NEXT = "com.windex.mochywidgets.ACTION_NEXT"
        const val ACTION_LIKE = "com.windex.mochywidgets.ACTION_LIKE"
        const val ACTION_SHUFFLE = "com.windex.mochywidgets.ACTION_SHUFFLE"
        const val ACTION_OPEN_PLAYER = "com.windex.mochywidgets.ACTION_OPEN_PLAYER"

        @Volatile
        var instance: MediaBridgeService? = null
    }
}
