package com.windex.mochywidgets.core

import android.content.Context
import com.windex.mochywidgets.widgets.Capsule4x1Widget

object WidgetRegistry {
    @Volatile
    var currentState: NowPlayingState = NowPlayingState()

    /**
     * Обновляет все зарегистрированные виджеты приложения.
     * Когда будем добавлять новые виджеты (4x2, 2x2, Винил и т.д.),
     * достаточно добавить сюда одну строчку вызова.
     */
    fun updateAllWidgets(context: Context, state: NowPlayingState = currentState) {
        currentState = state
        Capsule4x1Widget.updateAllInstances(context, state)
    }
}
