package com.windex.mochywidgets.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.windex.mochywidgets.R
import com.windex.mochywidgets.core.MediaBridgeService
import com.windex.mochywidgets.widgets.Capsule4x1Widget

class MainActivity : AppCompatActivity() {

    private lateinit var txtPermStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtPermStatus = findViewById(R.id.txt_perm_status)
        val btnGrant = findViewById<Button>(R.id.btn_grant_permission)
        val btnPin4x1 = findViewById<Button>(R.id.btn_pin_4x1)

        btnGrant.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        btnPin4x1.setOnClickListener {
            val mgr = AppWidgetManager.getInstance(this)
            val provider = ComponentName(this, Capsule4x1Widget::class.java)
            if (mgr.isRequestPinAppWidgetSupported) {
                mgr.requestPinAppWidget(provider, null, null)
            } else {
                Toast.makeText(
                    this,
                    "Зажми пустое место на рабочем столе → Виджеты → Mochy Widgets",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val enabled = isNotificationServiceEnabled()
        txtPermStatus.text = if (enabled) {
            "Статус доступа к медиасессии: Активен ✓"
        } else {
            "Статус доступа к медиасессии: Требуется разрешение"
        }
        if (enabled) {
            MediaBridgeService.instance?.pushStateToWidgets()
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return flat != null && flat.contains(packageName)
    }
}
