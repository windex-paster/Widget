package com.windex.mochywidgets.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect

data class NowPlayingState(
    val title: String = "Mochy",
    val artist: String = "Включи любой трек",
    val isPlaying: Boolean = false,
    val isLiked: Boolean = false,
    val isShuffle: Boolean = false,
    val albumArt: Bitmap? = null,
    val packageName: String? = null
)

object BitmapUtils {
    fun cropCircle(source: Bitmap?): Bitmap? {
        if (source == null) return null
        val size = minOf(source.width, source.height, 256)
        val scaled = Bitmap.createScaledBitmap(source, size, size, true)
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = Rect(0, 0, size, size)

        canvas.drawARGB(0, 0, 0, 0)
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(scaled, rect, rect, paint)
        return output
    }
}
